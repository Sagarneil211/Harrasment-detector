# Harassment-Video-Classification
A NLP based Image Turned Real Time Video Detection Model Integraed as a Web App
<h3>This Project is Still Under Development</h3>

Enter the live demo through this <a href = "https://65e2320372ff4c12f8225ac4--symphonious-puffpuff-714cc5.netlify.app/">link</a>
